//Filename:includes.h

#include "stm32f10x.h"

#include "vartypes.h"

