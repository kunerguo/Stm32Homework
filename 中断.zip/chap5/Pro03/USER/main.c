//Filename: main.c


#include "includes.h"

Int08U i=0,kun=0;

void  KeyInit()
{
	GPIO_InitTypeDef g;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	
	g.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1;
	g.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOB, &g);

	GPIO_SetBits(GPIOB, GPIO_Pin_0|GPIO_Pin_1);
}

void EXTIKeyInit(void)
{
	EXTI_InitTypeDef Exit_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource0);
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource1);
	Exit_InitStructure.EXTI_Line=EXTI_Line0 | EXTI_Line1;
	Exit_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	Exit_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
	Exit_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&Exit_InitStructure);
	
	NVIC_EnableIRQ(EXTI0_IRQn);	
	NVIC_EnableIRQ(EXTI1_IRQn);	
	NVIC_SetPriority(EXTI0_IRQn, 5);
	NVIC_SetPriority(EXTI1_IRQn, 6);
}




void LEDInit(void)
{
	GPIO_InitTypeDef g;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	g.GPIO_Pin = GPIO_Pin_1|GPIO_Pin_2;
	g.GPIO_Mode = GPIO_Mode_Out_PP;
	g.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(GPIOA, &g);
}

void EXTI0_IRQHandler()
{
	i++;
	if(i%2)
		GPIO_ResetBits(GPIOA, GPIO_Pin_1);
	else
		GPIO_SetBits(GPIOA, GPIO_Pin_1);
	EXTI_ClearFlag(EXTI_Line0);
	NVIC_ClearPendingIRQ(EXTI0_IRQn);
}

void EXTI1_IRQHandler()
{
	kun++;
	if(kun%2)
		GPIO_ResetBits(GPIOA, GPIO_Pin_2);
	else
		GPIO_SetBits(GPIOA, GPIO_Pin_2);
	EXTI_ClearFlag(EXTI_Line1);
	NVIC_ClearPendingIRQ(EXTI1_IRQn);
}


int main(void)
{
	LEDInit();
	KeyInit();
	EXTIKeyInit();
	GPIO_SetBits(GPIOA, GPIO_Pin_1);
	GPIO_SetBits(GPIOA, GPIO_Pin_2);

  while (1)
  {
		
  }
}
